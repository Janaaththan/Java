public class oppgave2_3 {
    public static void main(String[] args) {
    Planet Mars = new Planet("Mars", 3389F, 3.771F);

    Mars.PlanetPrint();
    }
}