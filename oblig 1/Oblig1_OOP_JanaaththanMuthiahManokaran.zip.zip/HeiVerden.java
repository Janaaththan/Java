public class HeiVerden{
    public static void main(String[] args) {
        System.out.println("Hei, verden!");
    }
}