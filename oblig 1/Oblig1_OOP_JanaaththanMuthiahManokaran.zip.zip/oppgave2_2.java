import java.util.Scanner;

        class oppgave2_2 {
        public static void main(String[] args) {
            Scanner vekt = new Scanner(System.in);
            System.out.println("Enter your weight:");

            float vektA = vekt.nextFloat();
            System.out.println("Moon weight:" + vektA * 0.17);
        }
        }